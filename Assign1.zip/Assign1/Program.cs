﻿using System;


    class Program
    {
        static void Main(string[] args)
        {
            int i;
            Console.WriteLine("Creating array");
            string[] str= new string[10];
            str[0]="Abhi";
            str[1]="Vikas";
            str[2]="Manish";
            str[3]="Bimal";
            str[4]="deepak";
            str[5]="Venkat";
            for(i=0;i<5;i++)
            {
                Console.WriteLine(str[i]);
            }
            Console.WriteLine("Created array is shown above");
            Console.WriteLine("Enter  name to search from above array");
            String str2 = Console.ReadLine();
            int j=0;
            for(i=0;i<5;i++)
            {
                if(str2==str[i])
                {
                    j=1;
                        if(j==1)
                    {
                    Console.WriteLine("matched string is "+ str[i]);
                    }
                   
                }
            }
        
            string[] newstr=new string[5];
            for(i=0;i<5;i++)
            {
                newstr[i] = str[i];
                Console.WriteLine(newstr[i]);

            }
            Console.WriteLine("Sorted array");
            Array.Sort(newstr,StringComparer.InvariantCulture);
            for(i=0;i<5;i++)
            {
                Console.WriteLine(newstr[i]);
            }
            i =newstr.Length;
            Console.WriteLine(i);


            
            

        }
    }